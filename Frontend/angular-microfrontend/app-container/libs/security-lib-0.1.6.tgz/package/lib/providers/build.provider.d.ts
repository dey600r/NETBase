import { Routes } from '@angular/router';
import { AutoRefreshTokenService, UserActivityService } from 'keycloak-angular';
import { AppConfig } from '../models/index';
import { SecurityAbstractService, SecurityJWTService, SecurityKeycloakService } from '../services/index';
export declare function buildRoutesJWT(config: AppConfig): Routes;
export declare function buildProviderAppConfig(config: AppConfig, routesApp: any[]): ({
    provide: import("@angular/core").InjectionToken<readonly import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof import("security-lib").APIInterceptor;
    multi: boolean;
} | import("@angular/core").EnvironmentProviders | typeof AutoRefreshTokenService | typeof UserActivityService | {
    provide: typeof SecurityAbstractService;
    useClass: typeof SecurityKeycloakService;
    multi: boolean;
    useValue?: undefined;
} | {
    provide: import("@angular/core").InjectionToken<import("keycloak-js").default>;
    useValue: any;
    useClass?: undefined;
    multi?: undefined;
})[] | ({
    provide: import("@angular/core").InjectionToken<readonly import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof import("security-lib").APIInterceptor;
    multi: boolean;
} | import("@angular/core").EnvironmentProviders | {
    provide: typeof SecurityAbstractService;
    useClass: typeof SecurityJWTService;
    multi: boolean;
})[];
