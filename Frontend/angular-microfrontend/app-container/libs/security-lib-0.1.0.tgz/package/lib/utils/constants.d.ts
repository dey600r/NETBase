export declare class AppConstants {
    static readonly LOCAL_STORAGE_USER = "userToken";
    static readonly SECURITY_PROTOCOL_KEYCLOAK = "keycloak";
    static readonly SECURITY_PROTOCOL_JWT = "jwt";
    static readonly UNKNOWN = "unknown";
}
