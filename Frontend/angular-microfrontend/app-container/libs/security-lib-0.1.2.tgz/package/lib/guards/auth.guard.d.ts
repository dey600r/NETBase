import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
export declare const createAuthJWTGuard: (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => boolean;
export declare const createAuthKeycloakGuard: (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => boolean;
