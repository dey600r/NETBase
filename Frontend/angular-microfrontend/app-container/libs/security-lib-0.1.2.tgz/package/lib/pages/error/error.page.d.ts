import * as i0 from "@angular/core";
export declare class ErrorPageComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorPageComponent, "app-error-page", never, {}, {}, never, never, true, never>;
}
