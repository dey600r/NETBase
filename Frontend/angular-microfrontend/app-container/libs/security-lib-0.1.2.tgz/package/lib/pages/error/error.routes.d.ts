import { Routes } from '@angular/router';
export declare const errorRoutes: Routes;
