export declare class AppConfigWithKeycloak {
    enable: boolean;
    url: string;
    realm: string;
    clientId: string;
    onLoad: string;
}
export declare class AppConfigWithRemotes {
    name: string;
    remoteEntry: string;
    exposedModule: string;
}
export declare class EnvConfig {
    production: boolean;
    configPath: string;
}
export declare class AppConfig {
    apiUrl: string;
    keycloak: AppConfigWithKeycloak;
    remotes: AppConfigWithRemotes[];
}
