export declare class SecurityLibUrlConstants {
    static readonly URL_API_LOGIN: string;
    static readonly URL_API_SIGNUP: string;
    static readonly URL_API_USER: string;
    static readonly URL_LOGIN: string;
    static readonly URL_SIGNUP: string;
    static readonly URL_HOME: string;
}
