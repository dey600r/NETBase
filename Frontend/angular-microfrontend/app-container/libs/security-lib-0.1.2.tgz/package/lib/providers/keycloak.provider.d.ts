import { IncludeBearerTokenCondition } from 'keycloak-angular';
import Keycloak from 'keycloak-js';
import { AppConfig } from '../models/index';
export declare function buildUrlCondition(config: AppConfig): IncludeBearerTokenCondition;
export declare function buildKeycloakInstance(config: AppConfig): Keycloak;
export declare function initializeKeycloak(config: AppConfig, keycloakInstance: Keycloak): () => Promise<void>;
