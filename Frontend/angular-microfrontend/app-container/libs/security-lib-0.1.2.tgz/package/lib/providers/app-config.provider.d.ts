import { InjectionToken, Provider } from "@angular/core";
import Keycloak from 'keycloak-js';
import { AppConfig, EnvConfig } from "../models/index";
export declare const ENV_CONFIG: InjectionToken<EnvConfig>;
export declare const APP_CONFIG: InjectionToken<AppConfig>;
export declare const KEYCLOAK_INSTANCE: InjectionToken<Keycloak>;
export declare function loadAppConfig(path: string): Promise<AppConfig>;
export declare function provideAppConfig(path: string): Promise<Provider>;
