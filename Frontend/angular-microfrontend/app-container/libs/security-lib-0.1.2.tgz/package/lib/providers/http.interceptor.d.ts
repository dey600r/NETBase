import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class APIInterceptor implements HttpInterceptor {
    private readonly urlNotSecurized;
    private readonly _userService;
    private readonly _materialService;
    private readonly _router;
    private readonly _appConfig;
    constructor();
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<APIInterceptor, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<APIInterceptor>;
}
export declare const ProviderInterceptorApp: {
    provide: import("@angular/core").InjectionToken<readonly HttpInterceptor[]>;
    useClass: typeof APIInterceptor;
    multi: boolean;
}[];
