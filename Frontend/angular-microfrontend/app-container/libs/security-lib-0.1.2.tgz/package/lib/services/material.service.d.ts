import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class MaterialService {
    private readonly _snackBar;
    private readonly _dialog;
    constructor();
    openSnackBar(message: string): void;
    openDialog(component: any, setting: {
        data: any;
        height: string;
        width: string;
    }): MatDialogRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MaterialService>;
}
