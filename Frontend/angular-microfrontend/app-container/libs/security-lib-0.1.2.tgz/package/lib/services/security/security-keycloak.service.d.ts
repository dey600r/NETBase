import { SecurityService } from './security.service';
import { IUserModel } from '../../models/index';
import * as i0 from "@angular/core";
export declare class SecurityKeycloakService extends SecurityService {
    private readonly _keycloak;
    user(): Promise<IUserModel>;
    logout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurityKeycloakService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SecurityKeycloakService>;
}
