import * as i0 from "@angular/core";
export declare class HttpService {
    private readonly _http;
    get<T>(url: string, params?: string): Promise<T>;
    post<T, R>(url: string, body: T): Promise<R>;
    private handleError;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpService>;
}
