import * as i0 from "@angular/core";
export declare class StorageService {
    setData<T>(key: string, data: T): void;
    getData(key: string): string | null;
    removeData(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StorageService>;
}
