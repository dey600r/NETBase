import { Router } from '@angular/router';
import { HttpService } from '../http.service';
import { MaterialService } from '../material.service';
import { SecurityAbstractService } from './security.interface';
import { UserService } from './user.service';
import { IUserModel } from '../../models/index';
import * as i0 from "@angular/core";
export declare class SecurityService extends SecurityAbstractService {
    protected readonly _httpService: HttpService;
    protected readonly _materialService: MaterialService;
    protected readonly _userService: UserService;
    protected readonly _router: Router;
    login(email: string, password: string): Promise<IUserModel>;
    validateToken(roles: string[]): boolean;
    user(): Promise<IUserModel>;
    logout(): void;
    validateRoles(rolesToken: string[], rolesPage: string[]): boolean;
    signup(firstName: string, lastName: string, location: string, userName: string, email: string, password: string): Promise<IUserModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurityService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SecurityService>;
}
