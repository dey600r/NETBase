import { SecurityService } from './security.service';
import { IUserModel } from '../../models/index';
import * as i0 from "@angular/core";
export declare class SecurityJWTService extends SecurityService {
    login(email: string, password: string): Promise<IUserModel>;
    user(): Promise<IUserModel>;
    validateToken(roles: string[]): boolean;
    logout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SecurityJWTService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SecurityJWTService>;
}
