import { IUserModel } from "../../models/index";
export interface ISecurityService {
    login(email: string, password: string): Promise<IUserModel>;
    validateToken(roles: string[]): boolean;
    validateRoles(rolesToken: string[], rolesPage: string[]): boolean;
    user(): Promise<IUserModel>;
    logout(): void;
    signup(firstName: string, lastName: string, location: string, userName: string, email: string, password: string): Promise<IUserModel>;
}
export declare abstract class SecurityAbstractService implements ISecurityService {
    abstract login(email: string, password: string): Promise<IUserModel>;
    abstract validateToken(roles: string[]): boolean;
    abstract validateRoles(rolesToken: string[], rolesPage: string[]): boolean;
    abstract user(): Promise<IUserModel>;
    abstract logout(): void;
    abstract signup(firstName: string, lastName: string, location: string, userName: string, email: string, password: string): Promise<IUserModel>;
}
