import { StorageService } from '../storage.service';
import { IUserModel } from '../../models/index';
import * as i0 from "@angular/core";
export declare class UserService {
    protected readonly _storageService: StorageService;
    setUser(user: IUserModel): void;
    getUser(): IUserModel | null;
    clearUser(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserService>;
}
