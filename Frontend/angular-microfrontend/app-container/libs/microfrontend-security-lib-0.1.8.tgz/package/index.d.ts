/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@microfrontend/security-lib" />
export * from './public-api';
