import * as i0 from '@angular/core';
import { inject, Injectable, InjectionToken, provideAppInitializer, Component } from '@angular/core';
import { Router, provideRouter } from '@angular/router';
import { HttpClient, HttpHeaders, HTTP_INTERCEPTORS, provideHttpClient, withFetch, withInterceptorsFromDi, withInterceptors } from '@angular/common/http';
import { firstValueFrom, catchError, throwError } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { createInterceptorCondition, AutoRefreshTokenService, UserActivityService, INCLUDE_BEARER_TOKEN_INTERCEPTOR_CONFIG, includeBearerTokenInterceptor } from 'keycloak-angular';
import Keycloak from 'keycloak-js';
import { CommonModule } from '@angular/common';

class AppConfigWithKeycloak {
    enable = false;
    url = '';
    realm = '';
    clientId = '';
    onLoad = 'login-required';
}
class AppConfigWithRemotes {
    name = '';
    remoteEntry = '';
    exposedModule = '';
}
class EnvConfig {
    production = false;
    configPath = '';
}
class AppConfig {
    apiUrl = '';
    keycloak = new AppConfigWithKeycloak();
    remotes = [];
}

class AppConstants {
    static LOCAL_STORAGE_USER = 'userToken';
    static SECURITY_PROTOCOL_KEYCLOAK = 'keycloak';
    static SECURITY_PROTOCOL_JWT = 'jwt';
    static UNKNOWN = 'unknown';
}

class SecurityLibUrlConstants {
    // SECURITY
    static URL_API_LOGIN = '/security/login';
    static URL_API_SIGNUP = '/security/signup';
    static URL_API_USER = '/security';
    // PAGES
    static URL_LOGIN = 'login';
    static URL_SIGNUP = 'signup';
    static URL_HOME = 'home';
}

class HttpService {
    _http = inject(HttpClient);
    get(url, params = '') {
        return firstValueFrom(this._http.get(`${url}`)
            .pipe(catchError((err, caught) => {
            const messageError = (err.error && err.error.message ? err.error.message : 'Global error');
            this.handleError('GET', messageError, params);
            return throwError(() => new Error(messageError));
        })));
    }
    post(url, body) {
        return firstValueFrom(this._http.post(`${url}`, body)
            .pipe(catchError((err, caught) => {
            const messageError = (err.error && err.error.message ? err.error.message : 'Global error');
            this.handleError('POST', messageError, body);
            return throwError(() => new Error(messageError));
        })));
    }
    handleError(title, err, body) {
        console.error(`${title}: ${err} - ${body}`);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: HttpService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: HttpService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: HttpService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class MaterialService {
    _snackBar = inject(MatSnackBar);
    _dialog = inject(MatDialog);
    constructor() { }
    openSnackBar(message) {
        this._snackBar.open(message, '', { duration: 3000 });
    }
    openDialog(component, setting) {
        return this._dialog.open(component, setting);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: MaterialService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: MaterialService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: MaterialService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class SecurityAbstractService {
}

class StorageService {
    setData(key, data) {
        localStorage.setItem(key, JSON.stringify(data));
    }
    getData(key) {
        try {
            return localStorage.getItem(key);
        }
        catch (e) {
            return null;
        }
    }
    removeData(key) {
        localStorage.removeItem(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: StorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: StorageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: StorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class UserService {
    _storageService = inject(StorageService);
    //#region USER
    setUser(user) {
        this._storageService.setData(AppConstants.LOCAL_STORAGE_USER, user);
    }
    getUser() {
        const user = this._storageService.getData(AppConstants.LOCAL_STORAGE_USER);
        return (!user ? null : JSON.parse(user));
    }
    clearUser() {
        this._storageService.removeData(AppConstants.LOCAL_STORAGE_USER);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: UserService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: UserService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: UserService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class SecurityService extends SecurityAbstractService {
    _httpService = inject(HttpService);
    _materialService = inject(MaterialService);
    _userService = inject(UserService);
    _router = inject(Router);
    //#region LOGIN
    login(email, password) {
        throw new Error("ONLY FOR JWT");
    }
    validateToken(roles) {
        throw new Error("ONLY FOR JWT");
    }
    user() {
        throw new Error("ONLY FOR JWT & KEYCLOAK");
    }
    logout() {
        throw new Error("ONLY FOR JWT && KEYCLOAK");
    }
    validateRoles(rolesToken, rolesPage) {
        // Allow the user to to proceed if no additional roles are required to access the route.
        if (!(rolesPage instanceof Array) || rolesPage.length === 0) {
            return true;
        }
        const validated = rolesPage.some((role) => rolesToken.includes(role));
        if (!validated) {
            this._materialService.openSnackBar('Unauthorized!!!');
        }
        return validated;
    }
    //#endregion LOGIN
    //#region SIGINUP
    signup(firstName, lastName, location, userName, email, password) {
        return this._httpService.post(SecurityLibUrlConstants.URL_API_SIGNUP, { firstName, lastName, location, userName, email, password });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class SecurityJWTService extends SecurityService {
    //#region LOGIN
    login(email, password) {
        return this._httpService.post(SecurityLibUrlConstants.URL_API_LOGIN, { email, password });
    }
    user() {
        return this._httpService.get(SecurityLibUrlConstants.URL_API_USER);
    }
    validateToken(roles) {
        let user = this._userService.getUser();
        if (!user || !user.token) {
            this._router.navigateByUrl(SecurityLibUrlConstants.URL_LOGIN);
            return false;
        }
        return this.validateRoles(user.roles, roles);
    }
    logout() {
        this._userService.clearUser();
        this._router.navigateByUrl(SecurityLibUrlConstants.URL_LOGIN);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityJWTService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityJWTService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityJWTService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

const ENV_CONFIG = new InjectionToken('ENV_CONFIG');
const APP_CONFIG = new InjectionToken('APP_CONFIG');
const KEYCLOAK_INSTANCE = new InjectionToken('KEYCLOAK_INSTANCE');
async function loadAppConfig(path) {
    const response = await fetch(path);
    if (!response.ok) {
        throw new Error('Error loading config file');
    }
    return response.json();
}
async function provideAppConfig(path) {
    const config = await loadAppConfig(path);
    return [{ provide: APP_CONFIG, useValue: config }];
}

class APIInterceptor {
    urlNotSecurized = [
        SecurityLibUrlConstants.URL_API_LOGIN,
        SecurityLibUrlConstants.URL_SIGNUP
    ];
    _userService = inject(UserService);
    _materialService = inject(MaterialService);
    _router = inject(Router);
    _appConfig = inject(APP_CONFIG);
    constructor() { }
    intercept(req, next) {
        let header = {
            'Content-Type': 'application/json'
        };
        if (!this.urlNotSecurized.some(x => req.url.endsWith(x))) {
            header['Authorization'] = `Bearer ${this._userService.getUser()?.token}`;
        }
        const apiReq = req.clone({
            headers: new HttpHeaders(header),
            url: `${this._appConfig.apiUrl}${req.url}`,
        });
        return next.handle(apiReq)
            .pipe(catchError((err, caught) => {
            switch (err.status) {
                case 401:
                case 403:
                    this._materialService.openSnackBar(err.statusText);
                    this._router.navigateByUrl(SecurityLibUrlConstants.URL_API_LOGIN);
                    break;
            }
            return throwError(() => err);
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: APIInterceptor, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: APIInterceptor });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: APIInterceptor, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });
const ProviderInterceptorApp = [
    { provide: HTTP_INTERCEPTORS, useClass: APIInterceptor, multi: true }
];

const createAuthJWTGuard = (route, state) => {
    return inject(SecurityAbstractService).validateToken(route.data['roles']);
};
const createAuthKeycloakGuard = (route, state) => {
    const key = inject(KEYCLOAK_INSTANCE);
    const _loginPort = inject(SecurityAbstractService);
    return !!key.authenticated && !!key.realmAccess && _loginPort.validateRoles(key.realmAccess.roles, route.data['roles']);
};

const AuthGuard = (route, state) => {
    const config = inject(APP_CONFIG);
    return (config.keycloak.enable ?
        createAuthKeycloakGuard(route, state) :
        createAuthJWTGuard(route, state));
};

// KEYCLOAK
function buildUrlCondition(config) {
    return createInterceptorCondition({
        //urlPattern: /^(http:\/\/localhost:8180)(\/.*)?$/i,
        //urlPattern: /^(config.keycloak.url)(\/.*)?$/i,
        urlPattern: new RegExp(`^(${config.keycloak.url})(\\/.*)?$`, 'i'),
        bearerPrefix: 'Bearer'
    });
}
function buildKeycloakInstance(config) {
    return new Keycloak({
        url: config.keycloak.url,
        realm: config.keycloak.realm,
        clientId: config.keycloak.clientId,
    });
}
function initializeKeycloak(config, keycloakInstance) {
    return async () => {
        try {
            if (window !== undefined) {
                const authenticated = await keycloakInstance.init({
                    onLoad: config.keycloak.onLoad, // or 'check-sso' for silent authentication
                    checkLoginIframe: false
                });
                console.log('✅ Keycloak initialized', authenticated ? 'User authenticated' : 'User not authenticated');
            }
        }
        catch (error) {
            //console.error('❌ Keycloak initialization failed', error);
        }
    };
}

function buildProviderAppConfig(config, routesApp, routesJWT) {
    if (config.keycloak.enable) {
        const keycloakInstance = buildKeycloakInstance(config);
        return [
            provideAppInitializer(initializeKeycloak(config, keycloakInstance)),
            provideRouter(routesApp),
            provideHttpClient(withFetch(), withInterceptorsFromDi(), withInterceptors([includeBearerTokenInterceptor])),
            AutoRefreshTokenService, UserActivityService,
            { provide: INCLUDE_BEARER_TOKEN_INTERCEPTOR_CONFIG, useValue: [buildUrlCondition(config)] },
            { provide: SecurityAbstractService, useClass: SecurityKeycloakService, multi: false },
            { provide: KEYCLOAK_INSTANCE, useValue: keycloakInstance },
            ...ProviderInterceptorApp
        ];
    }
    else {
        return [
            { provide: SecurityAbstractService, useClass: SecurityJWTService, multi: false },
            provideHttpClient(withFetch(), withInterceptorsFromDi()),
            provideRouter([...routesApp, ...routesJWT]),
            ...ProviderInterceptorApp
        ];
    }
}

class SecurityKeycloakService extends SecurityService {
    // INJECTABLES
    _keycloak = inject(KEYCLOAK_INSTANCE);
    user() {
        return new Promise((resolve, reject) => {
            this._keycloak.loadUserProfile().then((value) => {
                const user = {
                    email: (value.email ? value.email : AppConstants.UNKNOWN),
                    firstName: (value.firstName ? value.firstName : AppConstants.UNKNOWN),
                    lastName: (value.lastName ? value.lastName : AppConstants.UNKNOWN),
                    id: (value.id ? value.id : AppConstants.UNKNOWN),
                    location: AppConstants.UNKNOWN,
                    token: this._keycloak.token ? this._keycloak.token : AppConstants.UNKNOWN,
                    userName: (value.username ? value.username : AppConstants.UNKNOWN),
                    roles: this._keycloak.realmAccess?.roles ? this._keycloak.realmAccess?.roles : [AppConstants.UNKNOWN]
                };
                this._userService.setUser(user);
                resolve(user);
            });
        });
    }
    logout() {
        this._keycloak.logout({ redirectUri: location.origin }).then(() => {
            this._keycloak.clearToken();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityKeycloakService, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityKeycloakService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: SecurityKeycloakService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });

class ErrorPageComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: ErrorPageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.14", type: ErrorPageComponent, isStandalone: true, selector: "app-error-page", ngImport: i0, template: `
    <div style="text-align: center; margin-top: 50px;">
      <h1>Page unavailable</h1>
      <p>Please contact with the app administrator</p>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: ErrorPageComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-error-page',
                    standalone: true,
                    imports: [CommonModule],
                    template: `
    <div style="text-align: center; margin-top: 50px;">
      <h1>Page unavailable</h1>
      <p>Please contact with the app administrator</p>
    </div>
  `,
                }]
        }] });

var error_page = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ErrorPageComponent: ErrorPageComponent
});

const errorRoutes = [
    {
        path: '',
        loadComponent: () => Promise.resolve().then(function () { return error_page; }).then(m => m.ErrorPageComponent)
    }
];

/*
 * Public API Surface of security-lib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { APIInterceptor, APP_CONFIG, AppConfig, AppConfigWithKeycloak, AppConfigWithRemotes, AppConstants, AuthGuard, ENV_CONFIG, EnvConfig, ErrorPageComponent, HttpService, KEYCLOAK_INSTANCE, MaterialService, ProviderInterceptorApp, SecurityAbstractService, SecurityJWTService, SecurityKeycloakService, SecurityLibUrlConstants, SecurityService, StorageService, UserService, buildKeycloakInstance, buildProviderAppConfig, buildUrlCondition, createAuthJWTGuard, createAuthKeycloakGuard, errorRoutes, initializeKeycloak, loadAppConfig, provideAppConfig };
//# sourceMappingURL=security-lib.mjs.map
