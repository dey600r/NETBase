import { AutoRefreshTokenService, UserActivityService } from 'keycloak-angular';
import { AppConfig } from '../models/index';
import { SecurityAbstractService, SecurityJWTService, SecurityKeycloakService } from '../services/index';
export declare function buildProviderAppConfig(config: AppConfig, routesApp: any[], routesJWT: any[]): ({
    provide: import("@angular/core").InjectionToken<readonly import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof import("security-lib").APIInterceptor;
    multi: boolean;
} | import("@angular/core").EnvironmentProviders | typeof AutoRefreshTokenService | typeof UserActivityService | {
    provide: import("@angular/core").InjectionToken<import("keycloak-angular").IncludeBearerTokenCondition[]>;
    useValue: import("keycloak-angular").IncludeBearerTokenCondition[];
    useClass?: undefined;
    multi?: undefined;
} | {
    provide: typeof SecurityAbstractService;
    useClass: typeof SecurityKeycloakService;
    multi: boolean;
    useValue?: undefined;
} | {
    provide: import("@angular/core").InjectionToken<import("keycloak-js").default>;
    useValue: import("keycloak-js").default;
    useClass?: undefined;
    multi?: undefined;
})[] | ({
    provide: import("@angular/core").InjectionToken<readonly import("@angular/common/http").HttpInterceptor[]>;
    useClass: typeof import("security-lib").APIInterceptor;
    multi: boolean;
} | import("@angular/core").EnvironmentProviders | {
    provide: typeof SecurityAbstractService;
    useClass: typeof SecurityJWTService;
    multi: boolean;
})[];
